self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5569b28d8f7e4588d68e8821cbc8e4a9",
    "url": "@yield('content-viewer-url')/index.html"
  },
  {
    "revision": "95f329e2ecbd94d45633",
    "url": "@yield('content-viewer-url')/static/css/2.37be29a2.chunk.css"
  },
  {
    "revision": "05a9dc9caa25d7114c86",
    "url": "@yield('content-viewer-url')/static/css/main.e36a8043.chunk.css"
  },
  {
    "revision": "95f329e2ecbd94d45633",
    "url": "@yield('content-viewer-url')/static/js/2.5d0c7356.chunk.js"
  },
  {
    "revision": "f6681c7661458c30d69c95815d12061b",
    "url": "@yield('content-viewer-url')/static/js/2.5d0c7356.chunk.js.LICENSE.txt"
  },
  {
    "revision": "05a9dc9caa25d7114c86",
    "url": "@yield('content-viewer-url')/static/js/main.a20ce63d.chunk.js"
  },
  {
    "revision": "05c91422a8ff984def11",
    "url": "@yield('content-viewer-url')/static/js/runtime-main.779b656d.js"
  }
]);